from app.core.database import Database
from app.models.actividad import Actividad

class ActividadRepository:
    def __init__(self):
        self.db = Database()

    def obtener_todos(self):
        conn = self.db.get_connection()
        if not conn:
            return []
        cursor = conn.cursor()
        cursor.execute("SELECT id, nombre, descripcion, fecha_inicio, fecha_fin, lugar_id, categoria_id, estado_id, estado, creado, actualizado FROM actividad WHERE estado = TRUE ORDER BY id ASC;")
        filas = cursor.fetchall()
        conn.close()
        return filas

    def crear(self, act: Actividad):
        conn = self.db.get_connection()
        if not conn:
            return None
        cursor = conn.cursor()
        query = """
            INSERT INTO actividad (nombre, descripcion, fecha_inicio, fecha_fin, lugar_id, categoria_id, estado_id, estado, creado, actualizado)
            VALUES (%s, %s, %s, %s, %s, %s, %s, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id;
        """
        cursor.execute(query, (act.nombre, act.descripcion, act.fecha_inicio, act.fecha_fin, act.lugar_id, act.categoria_id, act.estado_id))
        nuevo_id = cursor.fetchone()['id']
        conn.commit()
        conn.close()
        return nuevo_id

    def eliminar_logico(self, act_id: int):
        conn = self.db.get_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        query = "UPDATE actividad SET estado = FALSE, actualizado = CURRENT_TIMESTAMP WHERE id = %s RETURNING id;"
        cursor.execute(query, (act_id,))
        resultado = cursor.fetchone()
        conn.commit()
        conn.close()
        return resultado is not None