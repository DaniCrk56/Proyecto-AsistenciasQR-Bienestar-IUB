from app.core.database import Database
from app.models.inscripcion import Inscripcion

class InscripcionRepository:
    def __init__(self):
        self.db = Database()

    def obtener_todos(self):
        conn = self.db.get_connection()
        if not conn:
            return []
        cursor = conn.cursor()
        cursor.execute("SELECT id, usuario_id, actividad_id, estado, creado, actualizado FROM inscripcion WHERE estado = TRUE ORDER BY id ASC;")
        filas = cursor.fetchall()
        conn.close()
        return filas

    def crear(self, ins: Inscripcion):
        conn = self.db.get_connection()
        if not conn:
            return None
        cursor = conn.cursor()
        query = """
            INSERT INTO inscripcion (usuario_id, actividad_id, estado, creado, actualizado)
            VALUES (%s, %s, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id;
        """
        cursor.execute(query, (ins.usuario_id, ins.actividad_id))
        nuevo_id = cursor.fetchone()['id']
        conn.commit()
        conn.close()
        return nuevo_id

    def eliminar_logico(self, ins_id: int):
        conn = self.db.get_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        query = "UPDATE inscripcion SET estado = FALSE, actualizado = CURRENT_TIMESTAMP WHERE id = %s RETURNING id;"
        cursor.execute(query, (ins_id,))
        resultado = cursor.fetchone()
        conn.commit()
        conn.close()
        return resultado is not None