from app.core.database import Database
from app.models.programa import Programa

class ProgramaRepository:
    def __init__(self):
        self.db = Database()

    def obtener_todos(self):
        conn = self.db.get_connection()
        if not conn:
            return []
        cursor = conn.cursor()
        cursor.execute("SELECT id, nombre, codigo, estado, creado, actualizado FROM programa WHERE estado = TRUE ORDER BY id ASC;")
        filas = cursor.fetchall()
        conn.close()
        return filas

    def crear(self, programa: Programa):
        conn = self.db.get_connection()
        if not conn:
            return None
        cursor = conn.cursor()
        query = """
            INSERT INTO programa (nombre, codigo, estado, creado, actualizado)
            VALUES (%s, %s, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id;
        """
        cursor.execute(query, (programa.nombre, programa.codigo))
        nuevo_id = cursor.fetchone()['id']
        conn.commit()
        conn.close()
        return nuevo_id

    def eliminar_logico(self, programa_id: int):
        conn = self.db.get_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        query = "UPDATE programa SET estado = FALSE, actualizado = CURRENT_TIMESTAMP WHERE id = %s RETURNING id;"
        cursor.execute(query, (programa_id,))
        resultado = cursor.fetchone()
        conn.commit()
        conn.close()
        return resultado is not None