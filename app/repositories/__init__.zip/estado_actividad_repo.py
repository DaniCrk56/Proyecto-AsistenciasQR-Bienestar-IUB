from app.core.database import Database
from app.models.estado_actividad import EstadoActividad

class EstadoActividadRepository:
    def __init__(self):
        self.db = Database()

    def obtener_todos(self):
        conn = self.db.get_connection()
        if not conn:
            return []
        cursor = conn.cursor()
        cursor.execute("SELECT id, nombre, descripcion, estado, creado, actualizado FROM estado_actividad WHERE estado = TRUE ORDER BY id ASC;")
        filas = cursor.fetchall()
        conn.close()
        return filas

    def crear(self, est: EstadoActividad):
        conn = self.db.get_connection()
        if not conn:
            return None
        cursor = conn.cursor()
        query = """
            INSERT INTO estado_actividad (nombre, descripcion, estado, creado, actualizado)
            VALUES (%s, %s, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id;
        """
        cursor.execute(query, (est.nombre, est.descripcion))
        nuevo_id = cursor.fetchone()['id']
        conn.commit()
        conn.close()
        return nuevo_id

    def eliminar_logico(self, est_id: int):
        conn = self.db.get_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        query = "UPDATE estado_actividad SET estado = FALSE, actualizado = CURRENT_TIMESTAMP WHERE id = %s RETURNING id;"
        cursor.execute(query, (est_id,))
        resultado = cursor.fetchone()
        conn.commit()
        conn.close()
        return resultado is not None