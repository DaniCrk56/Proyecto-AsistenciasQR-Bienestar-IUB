from app.core.database import Database
from app.models.asistencia import Asistencia

class AsistenciaRepository:
    def __init__(self):
        self.db = Database()

    def obtener_todos(self):
        conn = self.db.get_connection()
        if not conn:
            return []
        cursor = conn.cursor()
        cursor.execute("SELECT id, inscripcion_id, asistio, estado, creado, actualizado FROM asistencia WHERE estado = TRUE ORDER BY id ASC;")
        filas = cursor.fetchall()
        conn.close()
        return filas

    def crear(self, asis: Asistencia):
        conn = self.db.get_connection()
        if not conn:
            return None
        cursor = conn.cursor()
        query = """
            INSERT INTO asistencia (inscripcion_id, asistio, estado, creado, actualizado)
            VALUES (%s, %s, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id;
        """
        cursor.execute(query, (asis.inscripcion_id, asis.asistio))
        nuevo_id = cursor.fetchone()['id']
        conn.commit()
        conn.close()
        return nuevo_id

    def eliminar_logico(self, asis_id: int):
        conn = self.db.get_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        query = "UPDATE asistencia SET estado = FALSE, actualizado = CURRENT_TIMESTAMP WHERE id = %s RETURNING id;"
        cursor.execute(query, (asis_id,))
        resultado = cursor.fetchone()
        conn.commit()
        conn.close()
        return resultado is not None