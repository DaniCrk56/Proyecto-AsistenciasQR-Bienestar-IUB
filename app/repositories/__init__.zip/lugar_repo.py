from app.core.database import Database
from app.models.lugar import Lugar

class LugarRepository:
    def __init__(self):
        self.db = Database()

    def obtener_todos(self):
        conn = self.db.get_connection()
        if not conn:
            return []
        cursor = conn.cursor()
        cursor.execute("SELECT id, nombre, capacidad, ubicacion, estado, creado, actualizado FROM lugar WHERE estado = TRUE ORDER BY id ASC;")
        filas = cursor.fetchall()
        conn.close()
        return filas

    def crear(self, lugar: Lugar):
        conn = self.db.get_connection()
        if not conn:
            return None
        cursor = conn.cursor()
        query = """
            INSERT INTO lugar (nombre, capacidad, ubicacion, estado, creado, actualizado)
            VALUES (%s, %s, %s, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id;
        """
        cursor.execute(query, (lugar.nombre, lugar.capacidad, lugar.ubicacion))
        nuevo_id = cursor.fetchone()['id']
        conn.commit()
        conn.close()
        return nuevo_id

    def eliminar_logico(self, lugar_id: int):
        conn = self.db.get_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        query = "UPDATE lugar SET estado = FALSE, actualizado = CURRENT_TIMESTAMP WHERE id = %s RETURNING id;"
        cursor.execute(query, (lugar_id,))
        resultado = cursor.fetchone()
        conn.commit()
        conn.close()
        return resultado is not None