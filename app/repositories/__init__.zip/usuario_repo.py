from app.core.database import Database
from app.models.usuario import Usuario

class UsuarioRepository:
    def __init__(self):
        self.db = Database()

    def obtener_todos(self):
        conn = self.db.get_connection()
        if not conn:
            return []
        cursor = conn.cursor()
        cursor.execute("SELECT id, tipo_documento_id, numero_documento, nombre, apellido, email, rol_id, estado, creado, actualizado FROM usuario WHERE estado = TRUE ORDER BY id ASC;")
        filas = cursor.fetchall()
        conn.close()
        return filas

    def crear(self, usuario: Usuario):
        conn = self.db.get_connection()
        if not conn:
            return None
        cursor = conn.cursor()
        query = """
            INSERT INTO usuario (tipo_documento_id, numero_documento, nombre, apellido, email, password, rol_id, estado, creado, actualizado)
            VALUES (%s, %s, %s, %s, %s, %s, %s, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            RETURNING id;
        """
        cursor.execute(query, (
            usuario.tipo_documento_id, 
            usuario.numero_documento, 
            usuario.nombre, 
            usuario.apellido, 
            usuario.email, 
            usuario.password, 
            usuario.rol_id
        ))
        nuevo_id = cursor.fetchone()['id']
        conn.commit()
        conn.close()
        return nuevo_id

    def eliminar_logico(self, usuario_id: int):
        conn = self.db.get_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        query = "UPDATE usuario SET estado = FALSE, actualizado = CURRENT_TIMESTAMP WHERE id = %s RETURNING id;"
        cursor.execute(query, (usuario_id,))
        resultado = cursor.fetchone()
        conn.commit()
        conn.close()
        return resultado is not None